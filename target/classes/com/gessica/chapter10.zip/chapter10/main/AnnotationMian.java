package com.gessica.chapter10.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.gessica.chapter10.annotation.config.ApplicationConfig;
import com.gessica.chapter10.annotation.pojo.Role;
import com.gessica.chapter10.annotation.server.impl.RoleServerImpl;

public class AnnotationMian {

	public static void main(String[] args) {
//		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(PojoConfig.class);
//		Role role = applicationContext.getBean(Role.class);
//		System.out.println(role.getId());
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		Role role = context.getBean(Role.class);
		RoleServerImpl roleServerImpl = context.getBean(RoleServerImpl.class);
		roleServerImpl.printRoleinfo(role);
		context.close();
	}

}
