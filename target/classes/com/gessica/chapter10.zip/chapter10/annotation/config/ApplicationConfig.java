package com.gessica.chapter10.annotation.config;

import org.springframework.context.annotation.ComponentScan;

import com.gessica.chapter10.annotation.pojo.Role;
import com.gessica.chapter10.annotation.server.impl.RoleServerImpl;

@ComponentScan(basePackageClasses = {Role.class,RoleServerImpl.class})
//@ComponentScan(basePackages = {"com.gessica.chapter10.annotation.server","com.gessica.chapter10.annotation.pojo"})
//@ComponentScan(basePackages = {"com.gessica.chapter10.annotation.server","com.gessica.chapter10.annotation.pojo"},basePackageClasses = {Role.class,RoleServerImpl.class})

public class ApplicationConfig {

}
