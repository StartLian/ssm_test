package com.gessica.chapter10.annotation.pojo;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan
public class PojoConfig {

}
