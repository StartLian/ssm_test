package com.gessica.chapter10.annotation.server;

import com.gessica.chapter10.annotation.pojo.Role;

public interface RoleServer {
	public void printRoleinfo(Role role);
}
